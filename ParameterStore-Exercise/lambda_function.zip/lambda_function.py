import boto3, os

ssm = boto3.client('ssm')

ParameterName = os.environ['ParameterName']

def lambda_handler(event, context):
    print(ssm.get_parameter(Name=ParameterName,WithDecryption=True))