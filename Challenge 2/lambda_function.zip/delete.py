import sys

def delete(userID, table):

    # delete a record from the database
    table.delete_item(
        Key={
            'userID': userID
        }
    )

    # create a response
    response = {
        "statusCode": 200
    }

    return response
    
sys.modules[__name__] = delete