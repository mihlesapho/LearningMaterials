import sys
import json

def get(userID, table):

    # fetch a record from the database
    result = table.get_item(
        Key={
            'userID': userID
        }
    )

    # create a response
    response = {
        "statusCode": 200,
        "body": json.dumps(result['Item'])
    }

    return response

sys.modules[__name__] = get