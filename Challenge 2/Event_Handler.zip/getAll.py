import sys
import json

def getAll(table):

    # fetch a record from the database
    result = table.scan()
    
    # create a response
    response = {
        "statusCode": 200,
        "body": json.dumps(result['Items'])
    }

    return response

sys.modules[__name__] = getAll