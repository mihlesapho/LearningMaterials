import json
import boto3
import create
import delete
import getAll
import get

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    
    #Table Connection
    table = dynamodb.Table('Users')
    
    #Match type of CRUD operation from event
    
    if event['callType'] == 0:  #Create
            return create(event['Name'], event['Surname'], table)
    elif event['callType'] == 1: #Delete
            return delete(event['userID'], table)
    elif event['callType'] == 2: #get
            return get(event['userID'], table)
    elif event['callType'] == 3: #getAll
            return getAll(table)
    else:
            return "Invalid Call"
 