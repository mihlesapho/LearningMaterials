import sys
import logging
import json
import uuid

def create(Name, Surname, table):
    # TODO implement
    if Name  == "" or Surname == "":
        logging.error("Validation Failed")
        raise Exception("Couldn't create user.")

    item = {
        'userid': str(uuid.uuid1()),
        'Name': Name,
        'Surname': Surname,
    }

    # write the todo to the database
    table.put_item(Item=item)

    # create a response
    response = {
        "statusCode": 200,
        "body": json.dumps(item)
    }

    return response

sys.modules[__name__] = create