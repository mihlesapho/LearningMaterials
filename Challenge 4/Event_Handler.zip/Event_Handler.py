import json
import requests
import boto3
import base64
import json
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    
      #Secrete manager code starts here
    
    secret_name = "Infracost_Key"
    region_name = "us-west-2"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']

   # Secret manager code ends here
     
    # My Code       
    
    APIKey1 = secret ##Infracost API key

    # APIKeyRaw = secret
    # EndIndex = len(APIKeyRaw)-2
    # ProcessedAPIKey = APIKeyRaw[20:EndIndex]

    record = event['Records'][0] #Message from SQS
    payload = json.loads(record['body'])
    ec2InstanceType = payload['detail']['requestParameters']['instanceType'] 
    
    headers = {
        'X-Api-Key': APIKey1,
        # Already added when you pass json= but not when you pass data=
        # 'Content-Type': 'application/json',
    }
    
    json_data = {
        'query': '{products(filter: {vendorName: "aws", service: "AmazonEC2", region: "us-east-1", attributeFilters: [{key: "instanceType", value: "'+ ec2InstanceType +'"}, {key: "operatingSystem", value: "Linux"}, {key: "tenancy", value: "Shared"}, {key: "capacitystatus", value: "Used"}, {key: "preInstalledSw", value: "NA"}]}) { prices(filter: {purchaseOption: "on_demand"}) { USD } } } ',
    }
    
    response = requests.post('https://pricing.api.infracost.io/graphql', headers=headers, json=json_data)
    
    responseObj = {}
    responseObj['statusCode'] = 200
    responseObj['headers'] = {}
    responseObj['headers']['Content-Type'] = 'application/json'
    responseObj['body'] = json.dumps(response.text)
    
    ##SNS Code

    snsclient = boto3.client('sns')
    response = snsclient.publish(
        TopicArn='arn:aws:sns:us-east-1:116060500502:atcsevents',
        Message= responseObj['body'],
        Subject='Infracost Pricing',
        MessageStructure='string',
    )